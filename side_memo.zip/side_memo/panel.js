// panel.js  -----  メモをクリアしない版（storage 未使用）
const memo = document.getElementById('memo');
/* ここに Visibility API などを追加したい場合は続けて記述 */
